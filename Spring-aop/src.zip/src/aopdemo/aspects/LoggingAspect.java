package aopdemo.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect 
{
	@Pointcut("execution(* *(int,int))")
	private void point1() {}
	
	@Before("!point1()")
	public void beforeTarget()
	{
		System.out.println("=====> ASPECT executing before target");
	}

}
