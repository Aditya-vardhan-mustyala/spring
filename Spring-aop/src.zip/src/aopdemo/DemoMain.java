package aopdemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aopdemo.dao.AccountDAO;
import aopdemo.dao.MemberDAO;

public class DemoMain {

	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext  context =new AnnotationConfigApplicationContext(ConfigClass.class);
		
		AccountDAO acc=context.getBean("accountDAO",AccountDAO.class);
		MemberDAO mem=context.getBean("memberDAO",MemberDAO.class);
		
		acc.targetMethod1(1,3);
		System.out.println("2nd tym");
		acc.targetMethod2();
		
		System.out.println();
		mem.method();
		context.close();
		

	}

}
