package aopdemo.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO 
{
	public void targetMethod1(int a ,int b)
	{
		System.out.println("This is target code");
	}
	
	public void targetMethod2()
	{
		System.out.println("This is target 2");
	}


}
