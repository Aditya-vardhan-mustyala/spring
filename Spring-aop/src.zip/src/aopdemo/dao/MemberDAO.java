package aopdemo.dao;

import org.springframework.stereotype.Component;

@Component
public class MemberDAO 
{
	public void method()
	{
		System.out.println("method from member dao");
	}

}
